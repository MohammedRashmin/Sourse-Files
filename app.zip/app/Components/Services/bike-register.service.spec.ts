import { TestBed } from '@angular/core/testing';

import { BikeRegisterService } from './bike-register.service';

describe('BikeRegisterService', () => {
  let service: BikeRegisterService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(BikeRegisterService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
