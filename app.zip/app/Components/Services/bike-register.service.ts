import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root',
})
export class BikeRegisterService {
  private apiUrl =' https://localhost:7000/swagger/index.html'; // Replace with your backend API URL

  constructor(private http: HttpClient) {}

  // Fetch all brands and their models
  getBrands(): Observable<any> {
    return this.http.get('https://localhost:7000/api/Bike/AllBrands');
  }

  getModels(): Observable<any>{
    return this.http.get('https://localhost:7000/api/Bike/GetAllModels')
  }

  getModelById(id:number): Observable<any>{
    return this.http.get('https://localhost:7000/api/Bike/ModelByBrand' + id)
  }

  // Add new brand
  addBrand(brand: string): Observable<any> {
    return this.http.post('https://localhost:7000/api/Bike/AddBrand', { brandName: brand });
  }

  // Add new model to brand
  addModel(brandId: number, model: string): Observable<any> {
    return this.http.post('https://localhost:7000/api/Bike/AddModel', { brandId, modelName: model });
  }
  
}

