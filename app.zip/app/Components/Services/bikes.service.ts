import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { Bike } from '../home/home.component';

@Injectable({
  providedIn: 'root'
})
export class BikesService {

  private apiUrl = 'https://localhost:7000/api/Bike/AllBikes';
  private bikeUrl = 'https://localhost:7000/api/Bike';
  


  constructor(private http: HttpClient) {}

  getBikes(): Observable<Bike[]> {
    return this.http.get<Bike[]>(this.apiUrl);
  }


   updateBike( bikeData: any): Observable<any> {
    return this.http.put(`${this.bikeUrl}/UpdateBike`, bikeData);
  }


  deleteBike(registrationNumber: string): Observable<any> {
    return this.http.delete(`${this.bikeUrl}/DeleteBike${registrationNumber}`);
  }

  getBrands(): Observable<any> {
    return this.http.get('https://localhost:7000/api/Bike/AllBrands');
  }

  getModels(): Observable<any>{
    return this.http.get('https://localhost:7000/api/Bike/GetAllModels')
  }

  getModelById(id:number): Observable<any>{
    return this.http.get('https://localhost:7000/api/Bike/ModelByBrand' + id)
  }

  // Add new brand
  addBrand(brand: string): Observable<any> {
    return this.http.post('https://localhost:7000/api/Bike/AddBrand', { brandName: brand });
  }

  // Add new model to brand
  addModel(brandId: number, model: string): Observable<any> {
    return this.http.post('https://localhost:7000/api/Bike/AddModel', { brandId, modelName: model });


  }
  // Add bike API
  addBike(formData: FormData): Observable<any> {
    return this.http.post(`${this.bikeUrl}/AddBike`, formData);
  }

  // Upload image API
  uploadImage(file: File, unitId: string): Observable<any> {
    const formData = new FormData();
    formData.append('file', file);
    formData.append('unitId', unitId);
    return this.http.post(`${this.bikeUrl}/UploadImages`, formData);
  }
  

  requestRent(rentRequest: RentRequest): Observable<any> {
    const endpoint = 'https://localhost:7000/api/Rent/RequestRent';
    return this.http.post(endpoint, rentRequest);
  }
  
}

export interface RentRequest {
  userId: number;
  bikeId: number;
  registrationNumber: string;
  fromDate: string;
  toDate: string;
  fromLocation: string;
  toLocation: string;
  distance: number;
  amount: number;
  due: number;
  status: number; 
}
export interface BikeImage {
  imageId: number;
  unitId: number;
  image: string;
}

export interface BikeUnit {
  bikeId: number;
  unitId: number;
  registrationNumber: string;
  rentPerDay: number;
  year: number;
  bikeImages: BikeImage[];
}

export interface Bikes {
  brandName: string;
  modelName: string;
  bikeUnits: BikeUnit[];
}
