import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
@Injectable({
  providedIn: 'root'
})
export class RentalServiceService {
  private apiUrl = 'https://localhost:7000/api/Rent/AllRequest'; //endpoint url
  private baseUrl = 'https://localhost:7000/api/Rent'; //rent base url

 

  constructor(private http: HttpClient) {}

  getAllRequests(): Observable<any[]> {
    return this.http.get<any[]>(this.apiUrl);

  }

  declineRequest(requestId: number): Observable<any> {
    return this.http.post(`${this.baseUrl}/CancelRequest1?id=${requestId}`, {});
  }

  getRentalHistoryByUser(id: number): Observable<any[]> {
    return this.http.get<any[]>(`https://localhost:7000/api/Rent/RentalHistoryCountByUser?userId=${id}`);
  }

  updateRequestStatus(requestId: number, status: number): Observable<any> {
    const url = `${this.baseUrl}/AcceptRejectRequest`;
    const body = { id: requestId, status: status }; // JSON body
    console.log(`Sending request with body:`, body); // Debug log
    return this.http.put(url, body);
  }
  
  
  
  
 

 

}


