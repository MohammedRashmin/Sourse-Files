import { Component, model, OnInit } from '@angular/core';
import { BikeRegisterService } from '../Services/bike-register.service';

@Component({
  selector: 'app-admin-add-bike',
  templateUrl: './admin-add-bike.component.html',
  styleUrl: './admin-add-bike.component.css'
})
export class AdminAddBikeComponent implements OnInit {
  selectedBrand: string | null = null;
  selectedModel: string | null = null;

  bikeBrands: any[] = []; // Array to hold brands from the database
  filteredModels: string[] = [];
  selectedbikeModels: any[] = []

  constructor(private bikeRegisterService: BikeRegisterService) { }

  ngOnInit(): void {
    this.loadBrands();
  }

  // Load brands from the database
  loadBrands(): void {
    this.bikeRegisterService.getBrands().subscribe((response) => {
      console.log(response);
      this.bikeBrands = response;

    });
  }


  // Select a brand and load its models
  selectBrand(brand: any): void {
    this.selectedBrand = brand.brandName;
    this.filteredModels = brand.models || [model];
    this.bikeRegisterService.getModelById(brand.brandId).subscribe(data => {
      console.log(data);
     // brand.models = data;
     this.selectedbikeModels = data;
    })
  }

  // Select a model
  selectModel(model: any): void {
    this.selectedModel = model.modelName;
  }

  // Add a new bike brand
  addBrand(): void {
    const newBrand = prompt('Enter new bike brand:');
    if (newBrand) {
      this.bikeRegisterService.addBrand(newBrand).subscribe(() => {
        alert(`Brand "${newBrand}" added successfully!`);
        this.loadBrands();
      });
    }
  }

  // Add a new bike model
  addModel(): void {
    if (!this.selectedBrand) {
      alert('Please select a bike brand first!');
      return;
    }

    const newModel = prompt(`Enter new bike model for "${this.selectedBrand}":`);
    if (newModel) {
      // Find the brand object using the selected brand name
      const brand = this.bikeBrands.find((b) => b.brandName === this.selectedBrand);
      if (brand) {
        this.bikeRegisterService.addModel(brand.brandId, newModel).subscribe(() => {
          alert(`Model "${newModel}" added to "${this.selectedBrand}" successfully!`);

          // Update the models list for the selected brand
          if (!brand.models) {
            brand.models = [];
          }
          brand.models.push(newModel);
          // Add to local models array
          this.filteredModels = brand.models; // Refresh the filtered models list
        });
      } else {
        alert('Brand not found! Please reload and try again.');
      }
    }
  }
}
