import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { BikesService } from '../Services/bikes.service';

@Component({
  selector: 'app-admin-add-bike',
  templateUrl: './admin-add-bike.component.html',
  styleUrls: ['./admin-add-bike.component.css']
})
export class AdminAddBikeComponent implements OnInit {
  bikes: Bike[] = [];
  bikeForm: FormGroup;
  selectedBrand: string | null = null;
  selectedModel: string | null = null;

  bikeBrands: any[] = []; // Array to hold brands from the database
  filteredModels: string[] = [];
  selectedbikeModels: any[] = [];
  bikeUnits: string = 'DEFAULT_UNIT_ID';

  constructor(private fb: FormBuilder, private bikeService: BikesService) {
    this.bikeForm = this.fb.group({
      
      regNo: [''],
      bikePrice: [''],
      bikeImg: [null], // Store file here
      checkbox: [false]
    });
  }

  ngOnInit(): void {
    this.loadBrands();
    this.bikeService.getBikes().subscribe({
      next: (data: Bike[]) => {
        this.bikes = data;
      },
      error: (err) => {
        console.error('Error fetching bikes:', err);
      }
    });
  }

  loadBrands(): void {
    this.bikeService.getBrands().subscribe({
      next: (response) => {
        console.log(response);
        this.bikeBrands = response;
      },
      error: (err) => {
        console.error('Error fetching brands:', err);
      }
    });
  }

  // Select brand models
  selectBrand(brand: any): void {
    this.selectedBrand = brand.brandName;
    this.bikeService.getModelById(brand.brandId).subscribe({
      next: (data) => {
        console.log(data);
        this.selectedbikeModels = data;
      },
      error: (err) => {
        console.error('Error fetching models:', err);
      }
    });
  }

  // Select model
  selectModel(model: any): void {
    this.selectedModel = model.modelName;
  }

  // Add  brand
  addBrand(): void {
    const newBrand = prompt('Enter new bike brand:');
    if (newBrand) {
      this.bikeService.addBrand(newBrand).subscribe({
        next: () => {
          alert(`Brand "${newBrand}" added successfully!`);
          this.loadBrands();
        },
        error: (err) => {
          console.error('Error adding brand:', err);
        }
      });
    }
  }

  // Add a new bike model
  addModel(): void {
    if (!this.selectedBrand) {
      alert('Please select a bike brand first!');
      return;
    }

    const newModel = prompt(`Enter new bike model for "${this.selectedBrand}":`);
    if (newModel) {
     
      const brand = this.bikeBrands.find((b) => b.brandName === this.selectedBrand);
      if (brand) {
        this.bikeService.addModel(brand.brandId, newModel).subscribe({
          next: () => {
            alert(`Model "${newModel}" added to "${this.selectedBrand}" successfully!`);
            this.loadBrands();
          },
          error: (err) => {
            console.error('Error adding model:', err);
          }
        });
      } else {
        alert('Brand not found! Please reload and try again.');
      }
    }
  }

  
  onFileChange(event: any): void {
    const file = event.target.files[0];
    if (file) {
      this.bikeForm.patchValue({ bikeImg: file });
    }
  }

  // Submit the form
  submitForm(): void {
    if (this.bikeForm.invalid) {
      alert('Please fill all required fields!');
      return;
    }
  
    const formData = new FormData();
    
    formData.append('registrationNumber', this.bikeForm.value.regNo || '');
    formData.append('rentPerDay', this.bikeForm.value.bikePrice || '');
   // formData.append('brand', this.selectedBrand || '');
    formData.append('modelName', this.selectedModel || '');
    if (this.bikeForm.value.bikeImg) {
     // formData.append('Image', this.bikeForm.value.bikeImg); 
     // console.log(this.bikeForm.value.bikeImg);
     // this.bikeService.addImage(this.bikeForm.value.bikeImg
      
    }
  
    this.bikeService.addBike(formData).subscribe({
      next: (response) => {
        console.log('Bike added successfully:', response);
        alert('Bike added successfully!');
        this.resetForm();
      },
      error: (err) => {
        console.error('Error adding bike:', err);
        alert('Failed to add bike. Please check the logs for more details.');
      }
    });

    // this.bikeService. uploadImage(file:File,unitId:Number).subscribe({
    //   next: (response) => {
    //     console.log('Bike added successfully:', response);
    //     alert('Bike added successfully!');
    //     this.resetForm();
    //   },
    //   error: (err) => {
    //     console.error('Error adding bike:', err);
    //     alert('Failed to add bike. Please check the logs for more details.');
    //   }

    // })
  }
  
  
  
  resetForm(): void {
    this.bikeForm.reset();
    this.selectedBrand = null;
    this.selectedModel = null;
  }
  
  
}

// Interfaces
export interface BikeImage {
  imageId: number;
  unitId: number;
  image: string;
}

export interface BikeUnit {
  bikeId: number;
  unitId: number;
  registrationNumber: string;
  rentPerDay: number;
  year: number;
  bikeImages: BikeImage[];
}

export interface Bike {
  brandName: string;
  modelName: string;
  bikeUnits: BikeUnit[];
}
