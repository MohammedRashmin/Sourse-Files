import { Component } from '@angular/core';

@Component({
  selector: 'app-admin-dash-home',
  templateUrl: './admin-dash-home.component.html',
  styleUrl: './admin-dash-home.component.css'
})
export class AdminDashHomeComponent {

}
