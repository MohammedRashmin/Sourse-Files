import { Component } from '@angular/core';

@Component({
  selector: 'app-admin-delete-bike',
  templateUrl: './admin-delete-bike.component.html',
  styleUrl: './admin-delete-bike.component.css'
})
export class AdminDeleteBikeComponent {

}
