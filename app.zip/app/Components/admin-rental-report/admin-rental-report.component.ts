import { Component } from '@angular/core';

@Component({
  selector: 'app-admin-rental-report',
  templateUrl: './admin-rental-report.component.html',
  styleUrl: './admin-rental-report.component.css'
})
export class AdminRentalReportComponent {

}
