import { Component } from '@angular/core';
import { RentalServiceService } from '../Services/rental-service.service';

declare var bootstrap: any; // Import Bootstrap's modal functionality

@Component({
  selector: 'app-admin-rental-request',
  templateUrl: './admin-rental-request.component.html',
  styleUrls: ['./admin-rental-request.component.css']
})
export class AdminRentalRequestComponent {
  rentalRequests: any[] = [];
  rentalDetails: any[] | null = null; // Holds rental details for the modal

  constructor(private rentalService: RentalServiceService) {}

  ngOnInit(): void {
    this.fetchRentalRequests();
  }

  fetchRentalRequests(): void {
    this.rentalService.getAllRequests().subscribe(
      (data) => {
        console.log('Fetched rental requests:', data); // Debug log
        this.rentalRequests = data;
      },
      (error) => {
        console.error('Error fetching rental requests:', error);
      }
    );
  }

  viewDetails(id: number): void {
    // Reset rental details to show a loading state in the modal
    this.rentalDetails = null;
  
    // Call the service method to fetch rental history
    this.rentalService.getRentalHistoryByUser(id).subscribe(
      (data) => {
        this.rentalDetails = data;
  
        // Display the modal with rental details
        const modalElement = document.getElementById('rentalHistoryModal');
        const modal = new bootstrap.Modal(modalElement);
        modal.show();
      },
      (error) => {
        console.error('Error fetching rental history:', error);
        alert('Failed to fetch rental history. Please try again.');
      }
    );
  }
  

  declineRequest(requestId: number): void {
    const confirmDecline = confirm('Are you sure you want to decline this rental request?');
    if (!confirmDecline) return;

    this.rentalService.declineRequest(requestId).subscribe({
      next: () => {
        alert('Rental request declined, and notification email sent!');
        this.rentalRequests = this.rentalRequests.filter(request => request.id !== requestId);
      },
      error: (err) => {
        console.error('Error declining request:', err);
        alert('Failed to decline the rental request. Please try again.');
      }
    });
  }


 acceptRequest(requestId: number): void {
  if (!requestId) {
    alert('Invalid request ID.');
    return;
  }

  const confirmAccept = confirm('Are you sure you want to accept this rental request and set it to pending?');
  if (!confirmAccept) return;

  // Call the service to update the request statusp]
  this.rentalService.updateRequestStatus(requestId, 3).subscribe({
    next: () => {
      alert(`Rental request (ID: ${requestId}) accepted and status updated to Pending.`);
      
      // Update the UI by removing the request or marking it as "Pending"
      this.rentalRequests = this.rentalRequests.filter(request => request.requestId !== requestId);
    },
    error: (err) => {
      console.error('Error updating rental request status:', err);
      alert('Failed to update the rental request status. Please try again.');
    }
  });
}


  
  
}
