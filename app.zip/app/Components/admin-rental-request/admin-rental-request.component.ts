import { Component } from '@angular/core';
import jsPDF from 'jspdf';
import autoTable from 'jspdf-autotable';

@Component({
  selector: 'app-admin-rental-request',
  templateUrl: './admin-rental-request.component.html',
  styleUrl: './admin-rental-request.component.css'
})
export class AdminRentalRequestComponent {

    // Example data
    bikeRequests = [
      {
        bike: { name: 'Urban 125', brand: 'Aeon', image: 'BMW__R_1250_GS_.png' },
        startDate: 'Feb. 15, 2021',
        duration: '2 days',
        totalPrice: '37,40 €',
      },
    ];
  
    // Generate PDF
    generatePDF(): void {
      const doc = new jsPDF();
  
      // Title
      doc.setFontSize(16);
      doc.text('New Online Bike Requests', 10, 10);
  
      // Table headers and rows
      const headers = [['Bike', 'Start Date', 'Duration', 'Total Price']];
      const rows = this.bikeRequests.map((request) => [
        `${request.bike.name} (${request.bike.brand})`,
        request.startDate,
        request.duration,
        request.totalPrice,
      ]);
  
      // AutoTable for tabular data
      autoTable(doc, {
        startY: 20,
        head: headers,
        body: rows,
      });
  
      // Save the PDF
      doc.save('BikeRequests.pdf');
    }

}
