import { Component } from '@angular/core';
import jsPDF from 'jspdf';
import autoTable from 'jspdf-autotable';
import { generate } from 'rxjs';
@Component({
  selector: 'app-admin-update-bike',
  templateUrl: './admin-update-bike.component.html',
  styleUrl: './admin-update-bike.component.css'
})
export class AdminUpdateBikeComponent {

  updateBikes=[
 {   bike: { name: 'Urban 125', brand: 'Aeon', image: 'BMW__R_1250_GS_.png' },
    startDate: 'Feb. 15, 2021',
    duration: '2 days',
    totalPrice: '37,40 €',
  }
  ]
  generatePDF():void{
    const doc=new jsPDF;

    doc.setFontSize(16);
    doc.text("Updated Bikes",10,10);


    const headers=[['Bike','Start Date','Duration','Total Price']];
    const rows=this.updateBikes.map((update)=>[
      `${update.bike.name}(${update.bike.brand})`,
      update.startDate,
      update.duration,
      update.totalPrice,
    ]);

    autoTable(doc,{
      startY:20,
      head:headers,
      body:rows,
    });

    doc.save('Bike Update List.pdf')

}
}

