import { Component } from '@angular/core';

@Component({
  selector: 'app-admin-user-creation',
  templateUrl: './admin-user-creation.component.html',
  styleUrl: './admin-user-creation.component.css'
})
export class AdminUserCreationComponent {

}
