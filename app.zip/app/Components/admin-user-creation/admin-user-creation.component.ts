import { Component } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';

@Component({
  selector: 'app-admin-user-creation',
  templateUrl: './admin-user-creation.component.html',
  styleUrl: './admin-user-creation.component.css'
})
export class AdminUserCreationComponent {
  registrationForm: FormGroup;

  constructor(private fb: FormBuilder) {
    this.registrationForm = this.fb.group({
      firstName: ['', [Validators.required]],
      lastName: ['', [Validators.required]],
      email: ['', [Validators.required, Validators.email]],
      phoneNumber: [
        '',
        [Validators.required, Validators.pattern(/^\d{9}$/)]
      ],
      nic: [
        '',
        [
          Validators.required,
          Validators.pattern(/^\d{9}[vV]$|^\d{12}$/)
        ]
      ],
      licenceNumber: ['', [Validators.required, Validators.maxLength(12)]],
      password: ['', [Validators.required, Validators.maxLength(15),Validators.minLength(8)]]
    });
  }

  onSubmit(): void {
    if (this.registrationForm.invalid) {
      alert('Please fill out all required fields correctly.');
      return;
    }

    const formData = this.registrationForm.value;
    console.log('Registration Successful:', formData);
    alert('Registration successful!');
  }
}
