import { Component } from '@angular/core';
import { UserRequestService } from '../Services/user-request.service';
import { DomSanitizer } from '@angular/platform-browser';
import { ToastrService } from 'ngx-toastr';
import { animate, state, style, transition, trigger } from '@angular/animations';

@Component({
  selector: 'app-admin-user-request',
  templateUrl: './admin-user-request.component.html',
  styleUrl: './admin-user-request.component.css',
  animations: [
    trigger('flyInOut', [
      state('in', style({ transform: 'translateX(0)' })),
      transition('void => in', [
        style({ transform: 'translateX(-100%)' }),
        animate(300),
      ]),
      transition('in => void', [
        animate(300, style({ transform: 'translateX(100%)' })),
      ]),
    ]),
  ],
})
export class AdminUserRequestComponent {
  users: any[] = [];




  constructor(private userRequestService: UserRequestService, private toastr : ToastrService) {

  }

  ngOnInit(): void {
    this.loadUsers();
  }

  // Fetch user data from the service
  loadUsers(): void {
    this.userRequestService.getUser().subscribe({
      next: (data) => {
        this.users = data;
        // this.users = data.map(user => ({
        //   ...user,
        //   cameraCapture: user.cameraCapture.replace('/wwwroot/images/', '/images/'), // Correct the path
        // }));


      },
      error: (err) => {

        console.error('Error fetching users:', err);
      },
    });
  }

  accept(userId : string): void{
    this.userRequestService.updateUserRequestStatus(userId,6).subscribe({
      next: () => {
        this.toastr.success('User request accepted successfully!', 'Success');
        //this.updateLocalUserStatus(id, 6); 

      },
      error: (err : any) => {
        this.toastr.error('Failed to accept the user request.', 'Error');
        console.error(err);
      },
    });

  }

  decline(userId : string):void{

    this.userRequestService.updateUserRequestStatus(userId, 5).subscribe({
      next: () => {
        //alert("jbjjjjbjbj")

        this.toastr.success('User request declined successfully!', 'Success');
       // this.updateLocalUserStatus(id, 5); // Optionally update local data
      },
      error: (err: any) => {
        this.toastr.error('Failed to decline the user request.', 'Error');
        console.error(err);
      },
    });
    
  }

  // updateLocalUserStatus(id: string, status: number): void {
  //   const user = this.users.find((u) => u.id === id);
  //   if (user) {
  //     user.status = status;
  //   }
  // }


}
