import { Component } from '@angular/core';

@Component({
  selector: 'app-admin-user-request',
  templateUrl: './admin-user-request.component.html',
  styleUrls: ['./admin-user-request.component.css']
})
export class AdminUserRequestComponent {
  searchNameText: string = '';
  searchRentText:string='';
  users = [
    { name: 'Rasmin', email: 'Rin@example.com', brand: 'Yamaha', rent: '1000' },
    { name: 'Poul', email: 'Pol@example.com', brand: 'Honda', rent: '1200' },
    { name: 'Gopy', email: 'Gopy@example.com', brand: 'Suzuki', rent: '900' }
  ];
}

