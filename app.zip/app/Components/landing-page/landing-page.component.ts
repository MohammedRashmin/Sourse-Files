import { HttpClient } from '@angular/common/http';
import { Component } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-landing-page',
  templateUrl: './landing-page.component.html',
  styleUrl: './landing-page.component.css'
})
export class LandingPageComponent {
  users: any[]=[];


  constructor(private http:HttpClient, private router:Router){
    this.loadUser();
  }

  loadUser(){
    this.http.get('https://localhost:7000/api/User/AllUsers').subscribe((res:any)=>{
      this.users = res;
    })
  }

  logout(){
    localStorage.removeItem('token');
    this.router.navigate(['/home'])
  }

}
