import { Component } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { UserRequestService } from '../Services/user-request.service';
import { Route, Router } from '@angular/router';
import { ToastrModule, ToastrService } from 'ngx-toastr';
import { AuthGuard } from '../Services/auth.guard';
import { HttpClient } from '@angular/common/http';
import { Token } from '@angular/compiler';
import { jwtDecode } from 'jwt-decode';

@Component({
  selector: 'app-log-in',
  templateUrl: './log-in.component.html',
  styleUrl: './log-in.component.css'
})
export class LogInComponent {

  Token!: '';
  loginObj: any = {
    Email: '',
    Password: ''
  }

  constructor(private http: HttpClient, private router: Router, private toastr: ToastrService) {

  }

  onLogin() {

    this.http
      .post('https://localhost:7000/api/User/Login', this.loginObj, { responseType: 'text' })
      .subscribe({
        next: (res: string) => {
          // Store the token and navigate
          alert('Successfully Logged in');
          localStorage.setItem('token', res); // Save the token directly
          this.router.navigateByUrl('/user');
        },
        error: (err) => {
          console.error('Login error:', err);
          alert('Login failed');
        },
      });

      const token = localStorage.getItem('token');
      if(token){
        const decode = jwtDecode(token);
        localStorage.setItem('details', JSON.stringify(decode));
      }

  
  }

}
