import { Component } from '@angular/core';

@Component({
  selector: 'app-search-user',
  templateUrl: './search-user.component.html',
  styleUrl: './search-user.component.css'
})
export class SearchUserComponent {
  searchBrandText: string = '';
  searchRentText:string='';
  users = [
    { name: 'Rasmin', email: 'Rin@example.com' },
    { name: 'Poul', email: 'Pol@example.com' },
    { name: 'Gopy', email: 'Gopy@example.com' }
  ];

}
