// // import { Component } from '@angular/core';
// // import { FormBuilder, FormGroup } from '@angular/forms';
// // import { FormControl, Validators } from '@angular/forms';
// // import { IUserRegister, UserRegisterService } from '../Services/user-register.service';
// // import { ToastrService } from 'ngx-toastr';

// // @Component({
// //   selector: 'app-user-register',
// //   templateUrl: './user-register.component.html',
// //   styleUrl: './user-register.component.css'
// // })
// // export class UserRegisterComponent {

// //   registerForm : FormGroup;
// //   userRegister : IUserRegister;

// //   constructor(private fb:FormBuilder, private userService : UserRegisterService, private toaster : ToastrService){

// //     this.registerForm = this.fb.group({
// //       firstName : ['', [Validators.required]],
// //       lastName : ['', [Validators.required]],
// //       email:['', [Validators.email, Validators.required]],
// //       phoneNo : ['', [Validators.required]],
// //       nic : ['', [Validators.required]],
// //       licenceNo : ['', [Validators.required]],
// //       licencePhoto : ['',[Validators.required]],
// //       cameraPic : ['', Validators.required]

// //     })
// //   }

// // RegisterMember(registerForm:any){
// //   this.userRegister = registerForm;
// //   this.userRegister.cameraPic && this.userRegister.licencePhoto = this.onFileChange(event: any, controlName: string);

// //   this.userService.addUser(this.userRegister).subscribe(data =>{
// //     this.toaster.success("User Register Successfully Done!") 
// //   })
// //   console.log(registerForm.value);

// // }



// // onFileChange(event: any, controlName: string) {
// //   const file = event.target.files[0];
// //   if (file) {
// //     const reader = new FileReader();
// //     reader.onload = () => {
// //       this.registerForm.controls[controlName].setValue(reader.result?.toString().split(',')[1]);
// //     };
// //     reader.readAsDataURL(file);
// //   }
// // }
// // }

// import { Component, OnDestroy, ViewChild, ElementRef } from '@angular/core';
// import { FormBuilder, FormGroup, Validators } from '@angular/forms';
// import { IUserRegister, UserRegisterService } from '../Services/user-register.service';
// import { ToastrService } from 'ngx-toastr';
// import { HttpClient } from '@angular/common/http';

// @Component({
//   selector: 'app-user-register',
//   templateUrl: './user-register.component.html',
//   styleUrls: ['./user-register.component.css'] // Fixed typo here
// })
// export class UserRegisterComponent implements OnDestroy {
//   registerForm: FormGroup;
//   userRegister!: IUserRegister;
//   licenseImg : string = "";
//   cmaeraImg : string = ""

//   @ViewChild('videoElement') videoElement!: ElementRef<HTMLVideoElement>;
//   @ViewChild('canvasElement') canvasElement!: ElementRef<HTMLCanvasElement>;
//   @ViewChild('capturedImageElement') capturedImageElement!: ElementRef<HTMLImageElement>;

//   private stream: MediaStream | null = null;
//   public isCameraOpen = false;

//   constructor(public fb: FormBuilder,
//     private service: UserRegisterService,
//     private http: HttpClient,
//     private toastr: ToastrService) {
//     // Initialize the form group inside the constructor.
//     this.registerForm = this.fb.group({
//       firstName: [''],
//       lastName: [''],
//       email: [''],
//       password: [''],
//       mobileNumber: [''],
//       nic: [''],
//       licenseNumber: [''],
//       role: [2],
//       licenseImage: [null, [Validators.required]],
//       cameraCapture: [null, [Validators.required]],


//     });
//   }

//   async openCamera(): Promise<void> {
    
//     try {
//       this.stream = await navigator.mediaDevices.getUserMedia({ video: true });
//       const video = this.videoElement.nativeElement;
//       video.srcObject = this.stream;
//       video.play();
//       this.isCameraOpen = true;
//     } catch (error) {
//       console.error("Error accessing the camera:", error);
//       alert("Unable to access the camera.");
//     }
//   }
//   closeCamera(): void {
//     if (this.stream) {
//       this.stream.getTracks().forEach(track => track.stop()); // Stop all tracks of the media stream
//       this.stream = null;
//       this.isCameraOpen = false;
//       const video = this.videoElement.nativeElement;
//       video.srcObject = null; // Reset the video element's source object
//     }
//   }


//   // Function to take a photo
//   takePhoto(): void {
//     if (!this.stream) {
//       alert("Camera not open!");
//       return;
//     }else {

//     }

    

//     const video = this.videoElement.nativeElement;
//     const canvas = this.canvasElement.nativeElement;
//     canvas.width = video.videoWidth;
//     canvas.height = video.videoHeight;

//     const ctx = canvas.getContext("2d");
//     if (ctx) {
//       ctx.drawImage(video, 0, 0, canvas.width, canvas.height);
//       const imageData = canvas.toDataURL("image/png"); // Convert canvas to image data
//       const capturedImage = this.capturedImageElement.nativeElement;
//       capturedImage.src = imageData; // Set the image data to the img element
//       capturedImage.style.display = "block";
//       console.log(imageData);
//     }
//   }

//   // Clean up when the component is destroyed
//   ngOnDestroy(): void {
//     if (this.stream) {
//       this.stream.getTracks().forEach((track) => track.stop());
//     }
//   }


//   //original
//   // onFileChange(event: Event, controlName: string) {
//   //   const input = event.target as HTMLInputElement;

//   //   if (input.files && input.files.length > 0) {
//   //     const file = input.files[0];
//   //     const reader = new FileReader();

//   //     reader.onload = () => {
//   //       this.registerForm.controls[controlName].setValue(reader.result?.toString().split(',')[1]);
//   //     };

//   //     reader.readAsDataURL(file);
//   //   }
//   // }

//   // onFileChange(event: Event, controlName: string) {
//   //   const input = event.target as HTMLInputElement;
  
//   //   if (input.files && input.files.length > 0) {
//   //     const file = input.files[0];
//   //     const reader = new FileReader();
  
//   //     reader.onload = () => {
//   //       // Set the Base64 string of the file to the form control
//   //       const base64 = (reader.result as string).split(',')[1];
//   //       this.registerForm.controls[controlName].setValue(base64);
//   //     };
  
//   //     reader.readAsDataURL(file);
//   //   }
//   // }
  
//   //{{paulcode}}
//   // onFileChange(event: Event, controlName: string) {
//   //   const input = event.target as HTMLInputElement;
  
//   //   if (input.files && input.files.length > 0) {
//   //     const file = input.files[0];
//   //     const reader = new FileReader();
  
//   //     reader.onload = (input) => {
//   //       console.log(input.currentTarget);
//   //       // Set the Base64 string into the FormControl
//   //       const base64 = (reader.result as string).split(',')[1];
//   //       this.licenseImg = base64;
//   //       this.cmaeraImg = base64;
//   //       console.log(this.licenseImg);
//   //      // this.registerForm.get(controlName)?.setValue(base64);
//   //     };
  
//   //     reader.readAsDataURL(file); // Read the file as Base64 string
//   //   }
//   // }

//   //My Code
//   onFileChange(event: Event, controlName: string) {
//     const input = event.target as HTMLInputElement;
  
//     if (input.files && input.files.length > 0) {
//       const file = input.files[0];
//       const reader = new FileReader();
  
//       reader.onload = () => {
        
//         const base64 = (reader.result as string).split(',')[1]; 
//         if (controlName === 'licenseImage') {
//           this.registerForm.get(controlName)?.setValue(base64);
//           this.licenseImg = base64; 
//         } else if (controlName === 'cameraCapture') {
//           this.registerForm.get(controlName)?.setValue(base64);
//           this.cmaeraImg = base64; 
//         }
//       };
  
//       reader.readAsDataURL(file); 
//     }
//   }
  
  
  
// //{}
//   //RegisterMember() {
//   // console.log(JSON.stringify(this.registerForm.value.cameraPic));

//   // this.http.post('https://localhost:7000/api/User/CreateUser', this.registerForm.value, {
//   //   headers: { 'Content-Type': 'application/json' }
//   // }).subscribe();


//   // if (this.registerForm.valid) {
//   //   this.service.createUser(this.registerForm.value).subscribe({
//   //     next: res => {
//   //       console.log(res);

//   //     },
//   //     error: err => {
//   //       console.log('error', err);

//   //     }

//   //   })
//   //   console.log(JSON.stringify(this.registerForm.value));;

//   // }
//   //}

//   //Paul Code 
//   // RegisterMember() {
//   // //   if (this.registerForm.invalid) {
//   // //     console.error('Form is invalid');
//   // //     return;
//   // //   }

//   // //   console.log('Submitting form:', this.registerForm.value);
  

//   // this.service.addUser(this.registerForm.value).subscribe(data =>{
//   //   this.userRegister.role = parseInt(this.registerForm.value.roles);
//   //   this.registerForm.value.licenseImage = this.licenseImg;
//   //   this.registerForm.value.cameraCapture = this.cmaeraImg;


//   //     // next: res => {
//   //     //   console.log('Registration successful:', res);
//   //     // },
//   //     // error: err => {
//   //     //   if (err.status === 400) {
//   //     //     console.error(':', err.error);
//   //     //   } else {
//   //     //     console.error('Server error:', err);
//   //     //   }
//   //     // }
//   //   });
//   //   console.log(this.registerForm.value);
//   // }

//   //My Code
//   RegisterMember() {
    
//     this.registerForm.patchValue({
//       licenseImage: this.licenseImg,
//       cameraCapture: this.cmaeraImg,
//     });
  
//     this.service.addUser(this.registerForm.value).subscribe(
//       (data) => {
//         console.log("User registered successfully:", data);
//       },
//       (error) => {
//         console.error("Error during user registration:", error);
//       }
//     );
//     console.log(this.registerForm.value);
//   }
  
//   }
import { Component, ElementRef, ViewChild } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { HttpClient } from '@angular/common/http';
import { ToastrService } from 'ngx-toastr';

@Component({
  selector: 'app-user-register',
  templateUrl: './user-register.component.html',
  styleUrls: ['./user-register.component.css']
})
export class UserRegisterComponent {
  registerForm: FormGroup;
  licenseImage: File | null = null;
  cameraCapture: File | null = null;

  @ViewChild('videoElement') videoElement!: ElementRef<HTMLVideoElement>;
  @ViewChild('canvasElement') canvasElement!: ElementRef<HTMLCanvasElement>;
  @ViewChild('capturedImageElement') capturedImageElement!: ElementRef<HTMLImageElement>;

  private stream: MediaStream | null = null;
  public isCameraOpen = false;


  constructor(private fb: FormBuilder, private http: HttpClient,  private toastr: ToastrService) {
    this.registerForm = this.fb.group({
      FirstName: ['', [Validators.required]],
      LastName: ['', [Validators.required]],
      Email: ['', [Validators.required, Validators.email]],
      Password: ['', [Validators.required, Validators.minLength(6)]],
      MobileNumber: ['', [Validators.required, Validators.pattern('^[0-9]{10}$')]],
      NIC: ['', [Validators.required]],
      LicenseNumber: ['', [Validators.required]],
      Role: ['2', [Validators.required]],
      LicenseImage: [null],
      CameraCapture: [null],
    });
  }
  async openCamera(): Promise<void> {
    
    try {
      this.stream = await navigator.mediaDevices.getUserMedia({ video: true });
      const video = this.videoElement.nativeElement;
      video.srcObject = this.stream;
      video.play();
      this.isCameraOpen = true;
    } catch (error) {
      console.error("Error accessing the camera:", error);
      alert("Unable to access the camera.");
    }
  }
  closeCamera(): void {
    if (this.stream) {
      this.stream.getTracks().forEach(track => track.stop()); // Stop all tracks of the media stream
      this.stream = null;
      this.isCameraOpen = false;
      const video = this.videoElement.nativeElement;
      video.srcObject = null; // Reset the video element's source object
    }
  }


  // Function to take a photo
  takePhoto(): void {
    if (!this.stream) {
      alert("Camera not open!");
      return;
    }else {

    }

    

    const video = this.videoElement.nativeElement;
    const canvas = this.canvasElement.nativeElement;
    canvas.width = video.videoWidth;
    canvas.height = video.videoHeight;

    const ctx = canvas.getContext("2d");
    if (ctx) {
      ctx.drawImage(video, 0, 0, canvas.width, canvas.height);
      const imageData = canvas.toDataURL("image/png"); // Convert canvas to image data
      const capturedImage = this.capturedImageElement.nativeElement;
      capturedImage.src = imageData; // Set the image data to the img element
      capturedImage.style.display = "block";
      console.log(imageData);
    }
  }

  // Clean up when the component is destroyed
  ngOnDestroy(): void {
    if (this.stream) {
      this.stream.getTracks().forEach((track) => track.stop());
    }
  }


  onFileChange(event: Event, field: string): void {
    const file = (event.target as HTMLInputElement).files?.[0] || null;
    if (field === 'LicenseImage') {
      this.licenseImage = file;
    } else if (field === 'CameraCapture') {
      this.cameraCapture = file;
    }
  }

  RegisterMember(): void {
    if (this.registerForm.invalid) {
      console.error('Form is invalid.');
      return;
    }

    const formData = new FormData();
    Object.keys(this.registerForm.controls).forEach(key => {
      if (key !== 'LicenseImage' && key !== 'CameraCapture') {
        formData.append(key, this.registerForm.get(key)?.value);
      }
    });

    if (this.licenseImage) {
      formData.append('LicenseImage', this.licenseImage, this.licenseImage.name);
    }
    if (this.cameraCapture) {
      formData.append('CameraCapture', this.cameraCapture, this.cameraCapture.name);
    }

    this.http.post('https://localhost:7000/api/User/CreateUser', formData).subscribe({
      next: response => {
        console.log('User registered successfully:', response);
      },
      error: error => {
        console.error('Error registering user:', error);
      }
    });
  }
}

