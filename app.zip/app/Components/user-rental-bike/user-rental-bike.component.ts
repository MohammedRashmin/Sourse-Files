import { Component } from '@angular/core';

@Component({
  selector: 'app-user-rental-bike',
  templateUrl: './user-rental-bike.component.html',
  styleUrl: './user-rental-bike.component.css'
})
export class UserRentalBikeComponent {

}
