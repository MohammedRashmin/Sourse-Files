import { Component } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';

@Component({
  selector: 'app-user-update',
  templateUrl: './user-update.component.html',
  styleUrl: './user-update.component.css'
})
export class UserUpdateComponent {
  updateForm!: FormGroup;
  isCameraOpen = false;

  constructor(private fb: FormBuilder) {}

  ngOnInit(): void {
    this.updateForm = this.fb.group({
      FirstName: ['', [Validators.required]],
      LastName: ['', [Validators.required]],
      Email: [{ value: '', disabled: true }],
      MobileNumber: ['', [Validators.required, Validators.pattern(/^07[0-9]{10}$/)]],
      NIC: [{ value: '', disabled: true }],
      LicenseNumber: ['', [Validators.required]],
      LicenseImage: [''],
      Role: ['', [Validators.required]],
      CameraPic: ['']
    });

    this.loadUserData();
  }

  loadUserData() {
    const userData = {
      FirstName: 'Poul',
      LastName: 'Jesu',
      Email: 'Poul.jesu@example.com',
      MobileNumber: '0771234567',
      NIC: '9827608849865',
      LicenseNumber: 'B4647245',
      Role: '2'
    };

    this.updateForm.patchValue(userData);
  }

  onFileChange(event: any, fieldName: string) {
    const file = event.target.files[0];
    if (file) {
      this.updateForm.get(fieldName)?.setValue(file);
    }
  }

  openCamera() {
    this.isCameraOpen = true;
   
  }

  takePhoto() {
  }

  closeCamera() {
    this.isCameraOpen = false;
  }

  UpdateUser() {
    if (this.updateForm.valid) {
      const updatedData = this.updateForm.getRawValue(); 
      console.log('Updated User Data:', updatedData);
      // Call API to update the user
    }
  }

}
