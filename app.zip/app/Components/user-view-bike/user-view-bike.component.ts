import { Component } from '@angular/core';
import { Bikes, BikesService, RentRequest } from '../Services/bikes.service';
import { BikeUnit } from '../home/home.component';

@Component({
  selector: 'app-user-view-bike',
  templateUrl: './user-view-bike.component.html',
  styleUrl: './user-view-bike.component.css'
})
export class UserViewBikeComponent {
  bikes: Bikes[] = [];
  selectedBike: BikeUnit | null = null;

  // Form data bindings
  fromDate: string = '';
  toDate: string = '';
  fromLocation: string = '';
  toLocation: string = '';
  distance: number = 0;
  ridingOption: string = 'alone';

  constructor(private bikeService: BikesService) {}

  ngOnInit(): void {
    this.bikeService.getBikes().subscribe({
      next: (data: Bikes[]) => {
        this.bikes = data;
      },
      error: (err) => {
        console.error('Error fetching bikes:', err);
      }
    });
  }

  onRent(bikeUnit: BikeUnit): void {
    this.selectedBike = bikeUnit; // Save selected bike
  }

  calculateAmount(): number {
    if (this.selectedBike) {
      const days = this.calculateDays();
      return this.selectedBike.rentPerDay * days;
    }
    return 0;
  }

  calculateDays(): number {
    const start = new Date(this.fromDate);
    const end = new Date(this.toDate);
    return Math.ceil((end.getTime() - start.getTime()) / (1000 * 60 * 60 * 24)) || 1;
  }

  submitRent(): void {
    if (!this.selectedBike) {
      alert('No bike selected!');
      return;
    }

    const rentRequest: RentRequest = {
      userId: 1, // Replace with actual userId from authentication
      bikeId: this.selectedBike.bikeId,
      registrationNumber: this.selectedBike.registrationNumber,
      fromDate: this.fromDate,
      toDate: this.toDate,
      fromLocation: this.fromLocation,
      toLocation: this.toLocation,
      distance: this.distance,
      amount: this.calculateAmount(),
      due: 5, // Example hardcoded due days
      status: 1 // Pending status
    };

    this.bikeService.requestRent(rentRequest).subscribe({
      next: (response) => {
        alert('Rental request submitted successfully!');
        console.log('Response:', response);
        this.selectedBike = null; // Reset selection
      },
      error: (err) => {
        console.error('Error processing rent:', err);
        alert('Failed to process the rental request.');
      }
    });
  }

  cancelRent(): void {
    this.selectedBike = null; // Reset selected bike
  }
}


  
