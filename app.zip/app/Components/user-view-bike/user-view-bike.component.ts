import { Component } from '@angular/core';

@Component({
  selector: 'app-user-view-bike',
  templateUrl: './user-view-bike.component.html',
  styleUrl: './user-view-bike.component.css'
})
export class UserViewBikeComponent {

  
}
