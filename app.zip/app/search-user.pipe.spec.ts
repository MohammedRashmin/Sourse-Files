import { SearchUserPipe } from './search-user.pipe';

describe('SearchUserPipe', () => {
  it('create an instance', () => {
    const pipe = new SearchUserPipe();
    expect(pipe).toBeTruthy();
  });
});
