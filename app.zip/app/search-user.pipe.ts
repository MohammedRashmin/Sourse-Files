import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'searchUser'

})
export class SearchUserPipe implements PipeTransform {
  transform(items: any[], searchText: string, keys: string[] = ['email']): any[] {
    if (!items || !searchText) {
      return items;
    }
    searchText = searchText.toLowerCase();
    return items.filter(item =>
      keys.some(key => item[key] && item[key].toLowerCase().includes(searchText))
    );
  }
}

